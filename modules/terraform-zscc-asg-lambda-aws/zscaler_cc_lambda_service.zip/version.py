"""
Copyright (C) 2007-2025 Zscaler, Inc. All rights reserved.
Unauthorized copying of this file, via any medium is strictly prohibited
Proprietary and confidential
"""
# version.py
VERSION = "1.0.6.2"
