"""
Copyright (C) 2007-2024 Zscaler, Inc. All rights reserved.
Unauthorized copying of this file, via any medium is strictly prohibited
Proprietary and confidential
"""
import datetime
import json
import os
import re
import time
from datetime import datetime, timedelta
from typing import List, Dict, Any, Union, Tuple
from urllib.parse import urlparse

import boto3
import botocore
from botocore.exceptions import ClientError, BotoCoreError

from utils.log_config import setup_logger
from utils.metric_dimensions import retrieve_dimensions
from utils.secret_manager import get_secret_value
from zscaler_client.zscaler_api_client import ZscalerApiClient

# from zscaler_cc_lambda_service.utils.metric_dimensions import retrieve_dimensions
# from secret_manager import get_secret_value
# from zscaler_cc_lambda_service.zscaler_client.zscaler_api_client import ZscalerApiClient

logger = setup_logger(__name__)

# Set up the boto3 client for Auto Scaling and EC2
autoscaling_client = boto3.client('autoscaling')
ec2_client = boto3.client('ec2')
cloudwatch_client = boto3.client('cloudwatch')

custom_namespace = 'Zscaler/CloudConnectors'
custom_metric = 'cloud_connector_aggr_health'

# Resource sync (reconciler) configuration
EC_GROUP_NAME_PREFIX = 'zs-cc'
DEFAULT_PLACEHOLDER_UUID_GRACE_PERIOD_MIN = 15
RESOLVED_INSTANCE_ID_PATTERN = re.compile(r'^i-[0-9a-f]{8,17}$')
YOUNG_LIFECYCLE_STATE_PREFIXES = ('Pending', 'Warmed:Pending')
LIVE_EC2_STATES = ['pending', 'running', 'stopping', 'stopped']


def process_data(event: dict) -> dict:
    """
    Process different types of events based on their detail-type.

    Parameters:
        event (dict): Event data containing the 'detail-type' and other necessary information.

    Returns:
        dict: A response object with a status code and a body message.
    """
    try:
        env_vars = read_environment_variables()
        if env_vars is False:
            raise ValueError("Invalid environment variables configuration.")

        # Use the environment variables as needed, e.g., env_vars['missing_datapoints_unhealthy']

        detail_type = event.get('detail-type')

        if detail_type == 'Scheduled Event':
            response_message = process_scheduled_event(event)
        elif detail_type == 'EC2 Instance-terminate Lifecycle Action':
            response_message = process_terminate_lifecycle_action(event)
        elif detail_type == 'EC2 Instance State-change Notification':
            response_message = process_terminated_instance_action(event)
        elif detail_type == 'Resource Sync':
            response_message = process_resource_sync_event(event)
        else:
            response_message = f"Not supported: Unknown event detail-type: {detail_type}"
            logger.warning(response_message)
            return {
                'statusCode': 400,
                'body': json.dumps({'message': response_message})
            }

        # Check if response_message is None, indicating an error occurred in processing
        if response_message is None:
            error_message = f"Error processing event type: {detail_type}"
            logger.error(error_message)
            return {
                'statusCode': 500,
                'body': json.dumps({'message': error_message})
            }

        return {
            'statusCode': 200,
            'body': json.dumps({'message': response_message})
        }

    except Exception as e:
        logger.error(f"Error in process_data: {e}", exc_info=True)
        return {
            'statusCode': 500,
            'body': json.dumps({'message': f'Error: {str(e)}'})
        }


def read_environment_variables() -> Union[Dict[str, Union[str, int, bool]], bool]:
    """
    Read and validate the environment variables.

    Returns:
        Union[Dict[str, Union[str, int, bool]], bool]: A dictionary of environment variables
        with their processed values or False if any validation fails.
    """
    log_group_name = os.environ.get('AWS_LAMBDA_LOG_GROUP_NAME', 'dummy-log-group')
    log_stream_name = os.environ.get('AWS_LAMBDA_LOG_STREAM_NAME', 'dummy-log-stream')
    asg_list = os.environ.get('ASG_NAMES', 'dummy-asg-list')
    cc_url = os.environ.get('CC_URL', 'dummy-cc-url')
    secret_name = os.environ.get('SECRET_NAME', 'dummy-secret-name')
    certificate_verify_str = os.environ.get('CERTIFICATE_VERIFY', 'true').lower()

    try:
        hc_data_points = int(os.environ.get('HC_DATA_POINTS', '10'))
        hc_unhealthy_threshold = int(os.environ.get('HC_UNHEALTHY_THRESHOLD', '7'))
        hc_unhealthy_contiguous_dp = int(os.environ.get('HC_UNHEALTHY_CONTIGUOUS_DP', '5'))

        if hc_data_points <= 0 or hc_unhealthy_threshold <= 0 or hc_unhealthy_contiguous_dp <= 0:
            raise ValueError(
                "Environment variables HC_DATA_POINTS, HC_UNHEALTHY_THRESHOLD, "
                "and HC_UNHEALTHY_CONTIGUOUS_DP must be greater than 0.")
    except ValueError as e:
        logger.error(f"Invalid numeric environment variable settings: {e}")
        return False

    missing_datapoints_unhealthy_str = os.environ.get('MISSING_DATAPOINTS_UNHEALTHY', 'false').lower()
    if missing_datapoints_unhealthy_str not in ['true', 'false']:
        logger.error("Invalid value for MISSING_DATAPOINTS_UNHEALTHY; "
                     "it must be 'true' or 'false'.")
        return False
    missing_datapoints_unhealthy = missing_datapoints_unhealthy_str == 'true'

    if certificate_verify_str not in ['true', 'false']:
        logger.error("Invalid value for CERTIFICATE_VERIFY; "
                     "it must be 'true' or 'false'.")
        return False
    certificate_verify = certificate_verify_str == 'true'

    # Consolidated log message
    logger.info(
        f"## ENVIRONMENT VARIABLES ##\n"
        f"log_group_name: {log_group_name}, log_stream_name: {log_stream_name}, "
        f"asg_list: {asg_list}, cc_url: {cc_url}, secret_name: {secret_name}, "
        f"hc_data_points: {hc_data_points}, hc_unhealthy_threshold: {hc_unhealthy_threshold}, "
        f"hc_unhealthy_contiguous_dp: {hc_unhealthy_contiguous_dp}, "
        f"missing_datapoints_unhealthy: {missing_datapoints_unhealthy}, "
        f"certificate_verify: {certificate_verify}"
    )

    return {
        "log_group_name": log_group_name,
        "log_stream_name": log_stream_name,
        "asg_list": asg_list,
        "cc_url": cc_url,
        "secret_name": secret_name,
        "hc_data_points": hc_data_points,
        "hc_unhealthy_threshold": hc_unhealthy_threshold,
        "hc_unhealthy_contiguous_dp": hc_unhealthy_contiguous_dp,
        "missing_datapoints_unhealthy": missing_datapoints_unhealthy,
        "certificate_verify": certificate_verify
    }


def process_scheduled_event(event: Dict[str, Any]) -> Any:
    """
    Process a scheduled event.

    Args:
        event: The event data.

    Returns:
        The result of processing the fault management event.
    """
    logger.info(f"Processing scheduled event: {event}")
    try:
        result = process_fault_management_event(event)
        logger.info(f'Result: {result}')
    except Exception as e:
        logger.error(f"Error processing scheduled event: {e}", exc_info=True)
        result = None  # or some error indication depending on your design
    return result


def process_terminate_lifecycle_action(event: Dict[str, Any]) -> Any:
    """
    Process an EC2 Instance-terminate Lifecycle Action.

    Args:
        event: The event data.

    Returns:
        The result of processing the lifecycle termination event.
    """
    logger.info(f"Processing EC2 Instance-terminate Lifecycle Action: {event}")
    try:
        result = process_lifecycle_termination_events(event)
        logger.info(f'Result: {result}')
    except Exception as e:
        logger.error(f"Error processing lifecycle termination event: {e}", exc_info=True)
        result = None  # or some error indication depending on your design
    return result


def process_terminated_instance_action(event: Dict[str, Any]) -> Any:
    """
    Process a terminated instance action.

    Args:
        event: The event data.

    Returns:
        The result of processing the terminated instance event.
    """
    logger.info(f"Processing terminated instance action: {event}")
    try:
        result = process_terminated_instance_events(event)
        logger.info(f'Result: {result}')
    except Exception as e:
        logger.error(f"Error processing terminated instance event: {e}", exc_info=True)
        result = None  # or some error indication depending on your design
    return result


def get_asg_names():
    # asg_names_str = os.environ.get('ASG_NAMES', '["dummy_asg1","dummy_asg2"]')
    asg_names_str = os.environ.get('ASG_NAMES', '["dummy_asg1"]')
    asg_names = json.loads(asg_names_str)
    if not asg_names:
        raise ValueError("No ASG names provided in the environment variable.")
    return asg_names


# FIXME Can't use this call yet as no IAM rules setup lets use the other one for now
# def get_instances_in_service(asg_name):
#     response = autoscaling_client.describe_auto_scaling_groups(AutoScalingGroupNames=[asg_name])
#     instances = response['AutoScalingGroups'][0]['Instances']
#     return [instance for instance in instances if instance['LifecycleState'] == 'InService']


def get_instances_by_pool_membership(asg_name):
    response = autoscaling_client.describe_auto_scaling_groups(AutoScalingGroupNames=[asg_name])
    instances = response['AutoScalingGroups'][0]['Instances']

    in_service_instances = []
    in_warm_pool_instances = []
    ten_minutes = timedelta(minutes=10)

    # Check if warm pool is configured for the Auto Scaling group
    if 'WarmPoolConfiguration' in response['AutoScalingGroups'][0]:
        warm_pool_response = autoscaling_client.describe_warm_pool(AutoScalingGroupName=asg_name)
        warm_pool_instances = [instance['InstanceId'] for instance in warm_pool_response['Instances']]

        for instance in instances:
            if instance['InstanceId'] in warm_pool_instances:
                in_warm_pool_instances.append(instance)
            elif instance['LifecycleState'] == 'InService':
                instance_uptime = get_instance_uptime(instance['InstanceId'])
                if instance_uptime >= ten_minutes:
                    in_service_instances.append(instance)
    else:
        for instance in instances:
            if instance['LifecycleState'] == 'InService':
                instance_uptime = get_instance_uptime(instance['InstanceId'])
                if instance_uptime >= ten_minutes:
                    in_service_instances.append(instance)

    return in_service_instances, in_warm_pool_instances


def get_instance_uptime(instance_id):
    response = ec2_client.describe_instances(InstanceIds=[instance_id])
    launch_time = response['Reservations'][0]['Instances'][0]['LaunchTime']
    current_time = datetime.now(launch_time.tzinfo)
    uptime = current_time - launch_time
    return uptime


def get_autoscaling_group_name(instance_id):
    try:
        # Get the autoscaling group information for the instance
        response = ec2_client.describe_instances(InstanceIds=[instance_id])

        # Extract the autoscaling group name from the response
        autoscaling_group_name = None
        if 'Reservations' in response and len(response['Reservations']) > 0:
            instances = response['Reservations'][0]['Instances']
            if len(instances) > 0:
                tags = instances[0].get('Tags', [])
                for tag in tags:
                    if tag['Key'] == 'aws:autoscaling:groupName':
                        autoscaling_group_name = tag['Value']
                        break

        return autoscaling_group_name
    except botocore.exceptions.ClientError as e:
        error_message = e.response.get('Error', {}).get('Message', '')
        if 'InvalidInstanceID.NotFound' in error_message:
            logger.error(f"Instance ID '{instance_id}' does not exist")
        else:
            # Handle other ClientError exceptions if needed
            logger.error(f"An error occurred while retrieving the autoscaling group name")
        return None


def log_instance_info(instance_id, asg_name):
    logger.info(f"Instance ID: {instance_id}, ASG Name: {asg_name}")


def process_fault_management_event(event):
    logger.info(f"event: {event}")
    # Get the Auto Scaling group name
    try:
        asg_names = get_asg_names()

        for asg_name in asg_names:
            # instances, warm_pool_instances = get_instances_in_service(asg_name)
            instances, warm_pool_instances = get_instances_by_pool_membership(asg_name)
            # Note: instances returned is list of detailed instance and is not list of InstanceId's
            #
            # TODO check which is correct
            # instances_minus_warmpool = get_inservice_instances_not_in_warm_pool(asg_name)
            # instances = get_in_service_instances(asg_name)
            for instance in instances:
                # instance_id = instance['InstanceId']
                instance_id = instance
                log_instance_info(instance_id, asg_name)
                # query the custom health metric for this pair and get 10 entries at least. If HC_UNHEALTHY_THRESHOLD
                # out of HC_DATA_POINTS entries are unhealthy these are in env than mark instance as unhealthy
                base_url, dimensions = get_dimensions_for_health_metrics(asg_name, instance_id['InstanceId'])
                health_stats_datapoints_results = getstats_cloud_connector_gw_health(asg_name,
                                                                                     instance_id.get('InstanceId'),
                                                                                     dimensions)
                # TODO check if instance is up for at least 10 minutes
                # not needed as we already check if instance uptime is 10 minute
                # if not is_instance_in_service_for_x_amount_of_time(instance_id, hc_data_points):
                #     logger.info(f'instance_id: {instance_id} is running for less than {hc_data_points} minutes'
                #                 f'and hence Skipping health check')
                #     continue
                if if_unhealthy_ask_autoscaling_to_replace_instance(instance_id, asg_name,
                                                                    health_stats_datapoints_results):
                    logger.info(f'if_unhealthy_ask_autoscaling_to_replace_instance(): returned True, for instance: '
                                f'{instance_id} asg_name: {asg_name} '
                                f'health_stats_datapoints_results: {health_stats_datapoints_results}')
                    # delete the Zscaler resource as well
                    get_asg_instance_metadata_and_delete_zscaler_cloud_resource(asg_name, instance_id.get('InstanceId'))
                else:
                    logger.info(f'if_unhealthy_ask_autoscaling_to_replace_instance(): returned False, for instance: '
                                f'{instance_id} asg_name: {asg_name} hence it is HEALTHY')

        return f'health checked for all Inservice instances for autoscalinggroup list  successfully.'
    except Exception as e:
        logger.error(f"Error: {str(e)}")
        return "process_fault_management_event(): Error occurred while processing the ASGs."


def getstats_cloud_connector_gw_health(cgh_asgname, cgh_instanceid, dimensions):
    # Retrieve cloud_connector_aggr_health
    # dimensions is a list of dict
    # get first item
    hc_data_points = int(os.environ.get('HC_DATA_POINTS', '10'))
    dimensions_formatted_list = []
    for dimension in dimensions:
        for name, value in dimension.items():
            dimensions_formatted_list.append({
                'Name': name,
                'Value': value
            })

    # Needs to be Name, value pair dimensions when sent to get_metric_statistics
    logger.info(f'dimensions_formatted_list: {dimensions_formatted_list}')
    endtime = datetime.utcnow()
    # configured time +
    starttime = endtime - timedelta(minutes=hc_data_points + 2)
    response = []
    try:
        response = cloudwatch_client.get_metric_statistics(
            Namespace=custom_namespace,
            MetricName=custom_metric,

            Dimensions=dimensions_formatted_list,
            StartTime=starttime,
            EndTime=endtime,
            Period=60,
            Statistics=['Average']
        )
    except Exception as e:
        logger.error(f"An error occurred while retrieving  cloud_connector_aggr_health: {str(e)} ")
    logger.info(
        f"cloud_connector_aggr_health for {cgh_asgname}, "
        f"{cgh_instanceid} after get_metric_statistics response is : {response}")
    # Sort data points by timestamp
    datapoints = sorted(response['Datapoints'], key=lambda x: x['Timestamp'], reverse=True)
    if len(datapoints) == 0:
        logger.info(
            f'[cloud_connector_aggr_health for {cgh_asgname}, {cgh_instanceid}] No datapoints found between StartTime:'
            f' {starttime} and EndTime: {endtime}')
    else:
        logger.info(
            f'[cloud_connector_aggr_health for {cgh_asgname}, {cgh_instanceid}] '
            f'Number of datapoints processed between StartTime: {starttime} and EndTime: {endtime}: {len(datapoints)}')
    # Verify data
    if datapoints:
        average = datapoints[0]['Average']
        timestamp = datapoints[0]['Timestamp']
        logger.info(
            f"[cloud_connector_aggr_health for {cgh_asgname}, {cgh_instanceid}] FIRST datapoint: {average} "
            f"at {timestamp}")
    else:
        logger.info(f"[cloud_connector_aggr_health for {cgh_asgname}, {cgh_instanceid}] No data available ")

    return datapoints


'''
retrieve_last_n_entries() not used
'''


def retrieve_last_n_entries():
    start_time = datetime.datetime.now() - datetime.timedelta(minutes=30)
    end_time = datetime.datetime.now() - datetime.timedelta(minutes=10)
    logger.info('Retrieving metric data from {} to {}'.format(start_time, end_time))
    # need to add 2 extra to ensure we have at least HC_DATA_POINTS
    num_of_data_points_to_retrieve = os.environ.get('HC_DATA_POINTS', '10') + 2

    # FIXME pass entire dimensions for the desired metric instance instead of 1 dimension
    dimension_name = 'AutoScalingGroupName'
    dimension_value = 'AutoScalingGroupValue'

    response = cloudwatch_client.get_metric_data(
        MetricDataQueries=[
            {
                'Id': 'm1',
                'MetricStat': {
                    'Metric': {
                        'Namespace': custom_namespace,
                        'MetricName': custom_metric,
                        'Dimensions': [
                            {
                                'Name': dimension_name,
                                'Value': dimension_value
                            }
                        ]
                    },
                    'Period': 60,
                    'Stat': ['Average'],
                    'Unit': 'Percent'
                }
            }
        ],
        StartTime=start_time,
        EndTime=end_time,
        ScanBy='TimestampDescending',
        MaxDatapoints=num_of_data_points_to_retrieve
    )
    logger.info(f"retrieved get_metric_data(): {response}")
    logger.info(f'response["MetricDataResults"][0]["Values"]')
    if response['ResponseMetadata']['HTTPStatusCode'] == 200:
        if response['Messages']:
            logger.warning('Partial data received. Some metric data points may be missing.')

        logger.info('Last {num_of_data_points_to_retrieve} entries retrieved successfully!')

        # Process the metric data points
        if 'MetricDataResults' in response:
            for result in response['MetricDataResults']:
                if 'Timestamps' in result and 'Values' in result:
                    timestamps = result['Timestamps']
                    values = result['Values']

                    for timestamp, value in zip(timestamps, values):
                        logger.info('Timestamp: {}, Value: {}'.format(timestamp, value))
                else:
                    logger.warning('Missing Timestamps or Values in MetricDataResults.')
    else:
        logger.error(
            'Failed to retrieve metric data. Status code: {}'.format(response['ResponseMetadata']['HTTPStatusCode']))


def retrieve_all_dimensions():
    response = cloudwatch_client.list_metrics(
        Namespace=custom_namespace,
        MetricName=custom_metric
    )
    logger.debug(f'response: {response}')
    dimensions = [metric['Dimensions'] for metric in response['Metrics']]
    logger.debug(f'dimensions: {dimensions}')


def is_first_datapoint_healthy(datapoints):
    """
    Check if the first datapoint in the list has an 'Average' value of 100.

    Args:
        datapoints (list): A list of datapoint dictionaries.

    Returns:
        bool: True if the first datapoint is healthy (Average = 100), False otherwise.
    """
    if not datapoints:
        return False  # No datapoints to evaluate

    return datapoints[0]['Average'] == 100


def check_missing_timestamps(datapoints: List[Dict[str, any]]) -> Tuple[int, int, int]:
    """
    Checks for missing timestamps in a list of datapoints where each datapoint is a dictionary.

    :param datapoints: List of dictionaries, each containing a 'Timestamp' key with a datetime value.
    :return: A tuple containing the number of missing datapoints, the total number of datapoints, and the expected number of datapoints.
    """

    if not datapoints:
        raise ValueError("Datapoints list is empty")

    # Sort the datapoints based on Timestamp
    datapoints.sort(key=lambda x: x['Timestamp'])

    start_timestamp = datapoints[0]['Timestamp']
    end_timestamp = datapoints[-1]['Timestamp']
    total_datapoints = len(datapoints)
    expected_datapoints = int((end_timestamp - start_timestamp).total_seconds() / 60) + 1
    missing_datapoints = expected_datapoints - total_datapoints

    return missing_datapoints, total_datapoints, expected_datapoints


def is_stats_reported_unhealthy(datapoints: List[Dict[str, Union[int, float]]]) -> bool:
    """
    Determine if the given datapoints indicate an unhealthy state.

    Args:
        datapoints: A list of datapoint dictionaries with an 'Average' key.

    Returns:
        True if the stats are reported unhealthy, False otherwise.
    """
    env_vars = read_environment_variables()
    if env_vars is False:
        logger.error("Environment variable configuration is invalid.")
        return False

    hc_data_points = env_vars["hc_data_points"]
    hc_unhealthy_threshold = env_vars["hc_unhealthy_threshold"]
    hc_unhealthy_contiguous_dp = env_vars["hc_unhealthy_contiguous_dp"]
    missing_datapoints_unhealthy = env_vars["missing_datapoints_unhealthy"]

    if not datapoints and missing_datapoints_unhealthy:
        logger.info('Either none or empty and hence marking instance as unhealthy')
        return True

    missing_dps, total_dps, expected_dps = check_missing_timestamps(datapoints)
    logger.info(f"missing_dps:{missing_dps} total_dps:{total_dps} expected_dps:{expected_dps} ")

    datapoints_count_received = len(datapoints)
    logger.info(f"Number of datapoints received: {datapoints_count_received}")

    if datapoints_count_received < hc_data_points:
        logger.info(
            f"Insufficient number of datapoints received: {datapoints_count_received},"
            f"required: {hc_data_points}"
        )
        return False

    #  Need to slice, so we evaluate only hc_data_points
    datapoints = datapoints[:hc_data_points] if datapoints_count_received > hc_data_points else datapoints

    consecutive_count = 0
    max_consecutive_count = 0
    unhealthy_count = 0

    for datapoint in datapoints:
        #  ZTW VM small type return 0, 100 as health percentage value
        #  ZTW VM medium type returns 0, 50, 100 as health percentage value
        #  ZTW VM large type returns 0, 33, 66, 100 as health percentage value
        #  check for only unhealthy values in small type for now
        if datapoint['Average'] in [0]:
            consecutive_count += 1
            max_consecutive_count = max(max_consecutive_count, consecutive_count)
            unhealthy_count += 1
        else:
            consecutive_count = 0

    logger.info(
        f"unhealthy_count: {unhealthy_count}, hc_unhealthy_threshold: {hc_unhealthy_threshold}, "
        f"max_consecutive_count: {max_consecutive_count}")

    # Enhanced logging to indicate which condition was met
    if unhealthy_count >= hc_unhealthy_threshold:
        logger.info(f"Unhealthy count {unhealthy_count} exceeds or equals the threshold {hc_unhealthy_threshold}.")
        condition_met = True
    elif max_consecutive_count >= hc_unhealthy_contiguous_dp:
        logger.info(
            f"Max consecutive unhealthy count {max_consecutive_count} exceeds or equals"
            f"the threshold {hc_unhealthy_contiguous_dp}.")
        condition_met = True
    else:
        logger.info("Neither unhealthy count nor consecutive count conditions were met.")
        condition_met = False

    return condition_met


def set_instance_unhealthy(instance_id):
    """
    Set the health status of an EC2 instance to 'Unhealthy' in its Autoscaling Group.

    Parameters:
        instance_id (str): The ID of the instance to be marked as unhealthy.

    Returns:
        bool: True if the instance health status was successfully updated, False otherwise.
    """
    if not instance_id:
        logger.error("Instance ID is required")
        return False

    try:
        response = autoscaling_client.set_instance_health(
            InstanceId=instance_id,
            HealthStatus='Unhealthy',
            ShouldRespectGracePeriod=True
        )
        logger.info(f"Instance {instance_id} successfully marked as unhealthy. Response: {response}")
        return True

    except (BotoCoreError, ClientError) as e:
        logger.error(f"Failed to set instance {instance_id} as unhealthy due to: {e}")
        return False


def if_unhealthy_ask_autoscaling_to_replace_instance(instance_id, asg_name, health_stats_recent_datapoints_results):
    try:
        # Check if HC_UNHEALTHY_THRESHOLD out of HC_DATA_POINTS health probe results are 0 %
        if is_stats_reported_unhealthy(health_stats_recent_datapoints_results):
            instance_id_str = instance_id.get('InstanceId')
            if instance_id_str:
                logger.info(f"process_results found asg_name: {asg_name} instance {instance_id_str} "
                            f"unhealthy datapoint count of {health_stats_recent_datapoints_results.count(0)}")
                # Set the custom Auto Scaling group health check for the instance as unhealthy
                logger.info(f'Found instance {instance_id_str} in ASG {asg_name} Unhealthy, breaching threshold, '
                            f'sending message to autoscaling orchestration service to terminate the instance')
                if set_instance_unhealthy(instance_id_str):
                    return True
                else:
                    logger.warning(f"Failed to set instance {instance_id_str} as unhealthy. Skipping lifecycle action.")
                    return False
            else:
                logger.warning("Instance ID not found in the provided dictionary. Skipping lifecycle action.")
                return False
        else:
            logger.info(f"Instance {instance_id.get('InstanceId')} in ASG {asg_name} is healthy.")
            return False

    except Exception as e:
        logger.error("An unexpected error occurred while processing instance health status.")
        logger.exception(e)
        return False


def is_instance_in_service_for_x_amount_of_time(instance_id, inservice_age):
    response = autoscaling_client.describe_auto_scaling_instances(InstanceIds=[instance_id])
    instance_status = response['AutoScalingInstances'][0]['LifecycleState']
    transition_time = response['AutoScalingInstances'][0]['LifecycleTransitionStart']

    if instance_status == 'InService':
        current_time = datetime.now(transition_time.tzinfo)
        elapsed_time = current_time - transition_time
        elapsed_minutes = elapsed_time.total_seconds() / 60

        if elapsed_minutes >= inservice_age:
            return True

    return False


def get_inservice_instances_not_in_warm_pool(auto_scaling_group_name):
    # Get the Auto Scaling group details
    response = autoscaling_client.describe_auto_scaling_groups(AutoScalingGroupNames=[auto_scaling_group_name])
    instances = response['AutoScalingGroups'][0]['Instances']
    warm_pool_instances = response['AutoScalingGroups'][0].get('WarmPoolConfiguration', {}).get('Instances', [])

    # Find instances that are InService and not in the warm pool
    inservice_instances = []
    for instance in instances:
        instance_id = instance['InstanceId']
        if instance_id not in warm_pool_instances and instance['LifecycleState'] == 'InService':
            inservice_instances.append(instance_id)

    return inservice_instances


# TODO Somehow this returns warm pool instances that are initializing
# maybe I  have to filter this out
def get_in_service_instances(auto_scaling_group_name):
    # Retrieve in-service instances from the Auto Scaling group
    response = ec2_client.describe_instances(
        Filters=[
            {'Name': 'tag:aws:autoscaling:groupName', 'Values': [auto_scaling_group_name]},
            {'Name': 'instance-state-name', 'Values': ['running']}
        ]
    )

    in_service_instances = []
    for reservation in response['Reservations']:
        for instance in reservation['Instances']:
            instance_id = instance['InstanceId']
            if not instance['LaunchTime'] >= 10 * 60:
                logger.info(f'launchtime less than 10 minutes instanceid: {instance_id} skipping')
            in_service_instances.append(instance_id)
            logger.info(f"In-Service Instance ID: {instance_id}")

    return in_service_instances


def extract_ec2_instance_id_and_asg_name(event):
    if event['detail-type'] == 'EC2 Instance-terminate Lifecycle Action':
        ec2_instance_id = event['detail']['EC2InstanceId']
        autoscaling_group_name = event['detail']['AutoScalingGroupName']
    elif event['detail-type'] == 'EC2 Instance State-change Notification':
        ec2_instance_id = event['detail']['instance-id']
        logger.info(
            f'Find out the autoscaling group name for instanceId: {ec2_instance_id}')
        autoscaling_group_name = get_autoscaling_group_name(ec2_instance_id)
        if autoscaling_group_name:
            logger.info(
                f'Found instanceId: {ec2_instance_id} autoscaling_group_name {autoscaling_group_name}')
    else:
        logger.info("Unsupported event type.")
        return None, None

    logger.info(f"EC2 Instance ID: {ec2_instance_id}")
    logger.info(f"Autoscaling Group Name: {autoscaling_group_name}")
    return ec2_instance_id, autoscaling_group_name


def extract_zsgroupid_zsvmid_from_dimensions(dimensions):
    zs_group_id = None
    zs_vm_id = None
    if dimensions and len(dimensions) > 0:
        for dimension in dimensions:
            dimension_name = dimension['Name']
            dimension_value = dimension['Value']
            if dimension_name == 'ZsGroupId':
                zs_group_id = dimension_value
            elif dimension_name == 'ZsVmId':
                zs_vm_id = dimension_value
            # Break out of the loop if both dimensions are found
            if zs_group_id and zs_vm_id:
                break

    return zs_group_id, zs_vm_id


def process_lifecycle_termination_events(event: Dict[str, Any]) -> Dict[str, Any]:
    """
    Process the lifecycle termination events and handle instances being sent to the warm pool instead of termination.

    Args:
        event (Dict[str, Any]): The event data received from the AWS Auto Scaling service via EventBridge service.

    Returns:
        Dict[str, Any]: The response indicating the action taken or Done.

    Raises:
        Exception: If there is an error during the processing.

    """
    logger.info(f"received: {event}")

    # Get the instance ID, asg_name from the event
    instance_id, asg_name = extract_ec2_instance_id_and_asg_name(event)
    # Get lifecycle action token from the event
    token = event['detail']['LifecycleActionToken']

    # read the lifecycle hook name from asg
    hook_name = event['detail']['LifecycleHookName']
    logger.info(f"hook_name: {hook_name} asgName: {asg_name}")
    logger.info(f"instance_id: {instance_id}")
    message = 'Handling Lifecycle Termination event'
    response = {
        'statusCode': 200,
        'body': message
    }
    # if warm pool is enabled and re-use policy in use, the instance won't be terminated.
    # so it should be ignored
    # Check if the instance is being sent to the warm pool instead of termination.
    # Both fields must be present and match: absent Origin/Destination must not
    # count as warm-pool reuse, or real terminations get skipped.
    if (
            event['detail']['LifecycleTransition'] == 'autoscaling:EC2_INSTANCE_TERMINATING'
            and event['detail'].get('Origin') == 'AutoScalingGroup'
            and event['detail'].get('Destination') == 'WarmPool'
    ):
        message = 'Instance is returned to warm pool and no action is needed'
        response = {
            'statusCode': 200,
            'body': message
        }
        return response

    # Otherwise instances are getting terminated: validate, delete the zscaler resource and notify autoscale service
    if event['detail']['LifecycleTransition'] == 'autoscaling:EC2_INSTANCE_TERMINATING' and \
            event['detail']['LifecycleHookName'] == hook_name:
        response = autoscaling_client.describe_auto_scaling_instances(InstanceIds=[instance_id])
        logger.info(f"describe_auto_scaling_instances: {response}")
        instances = response['AutoScalingInstances']
        # if instances and instances[0]['LifecycleState'] == 'Warmed:Terminating:Wait':
        # handle terminating events and not just warmed:Terminating ones
        if instances:
            get_asg_instance_metadata_and_delete_zscaler_cloud_resource(asg_name, instance_id)

            success = complete_lifecycle_action(hook_name, asg_name, token, instance_id)

            if success:
                # Handle successful completion of the lifecycle action
                message = "Lifecycle action completed successfully."
                logger.info(f"message: {message}")
                return response
            else:
                # Handle failure in completing the lifecycle action
                message = "Failed to complete the lifecycle action."
                logger.info(f"message: {message}")
                return response

        else:
            message = "life cycle action NOT  Warmed:Terminating:Wait or Terminating:Wait and hence Ignoring it"
            logger.info(f"message: {message}")
            return response

    message = 'Autoscale Lifecycle action completed.'
    logger.info(f"message: {message} Response: {response}")
    return response


def complete_lifecycle_action(hook_name, asg_name, token, instance_id):
    retry_attempts = 5
    retry_delay = 60  # Initial delay in seconds
    max_delay = 300  # Maximum delay in seconds

    try:
        if hook_name is None:
            # Get the termination lifecycle hook name from the ASG
            response = autoscaling_client.describe_lifecycle_hooks(AutoScalingGroupName=asg_name)
            hooks = response['LifecycleHooks']
            for hook in hooks:
                if hook['LifecycleTransition'] == 'autoscaling:EC2_INSTANCE_TERMINATING':
                    hook_name = hook['LifecycleHookName']

        # Check if the instance is in a 'Terminating:Wait' or 'Warmed:Terminating:Wait' state
        response = autoscaling_client.describe_auto_scaling_instances(InstanceIds=[instance_id])
        if 'AutoScalingInstances' in response:
            asg_instance = response['AutoScalingInstances'][0]
            lifecycle_state = asg_instance['LifecycleState']
            if lifecycle_state.startswith('Terminating:Wait') or lifecycle_state.startswith('Warmed:Terminating:Wait'):
                for attempt in range(retry_attempts):
                    try:
                        if token is None:
                            response = autoscaling_client.complete_lifecycle_action(
                                LifecycleHookName=hook_name,
                                AutoScalingGroupName=asg_name,
                                LifecycleActionResult='CONTINUE',
                                InstanceId=instance_id
                            )
                        else:
                            response = autoscaling_client.complete_lifecycle_action(
                                LifecycleHookName=hook_name,
                                AutoScalingGroupName=asg_name,
                                LifecycleActionToken=token,
                                LifecycleActionResult='CONTINUE',
                                InstanceId=instance_id
                            )

                        logger.debug(f"Lifecycle action response: {response}")

                        if response['ResponseMetadata']['HTTPStatusCode'] == 200:
                            logger.info("Lifecycle action completed successfully.")
                            return True

                    except Exception as e:
                        logger.warning("Failed to complete the lifecycle action.")
                        logger.exception(e)

                    logger.warning("Retrying...")
                    time.sleep(retry_delay)
                    retry_delay = min(2 * retry_delay, max_delay)

                logger.warning("Exceeded maximum retry attempts. Failed to complete the lifecycle action.")
                return False
            else:
                logger.warning(
                    f"Instance is not in the expected 'Terminating:Wait' or 'Warmed:Terminating:Wait' state. "
                    f"Current state: {lifecycle_state}")
                return False
        else:
            logger.warning("Failed to retrieve instance information. Skipping lifecycle action.")
            return False

    except Exception as e:
        logger.warning("Failed to complete the lifecycle action.")
        logger.exception(e)
        return False


def extract_zs_group_vm_ids(data):
    try:
        if not isinstance(data, list) or len(data) == 0:
            raise ValueError("Invalid data object")

        zs_group_id = data[0].get('ZsGroupId')
        zs_vm_id = data[0].get('ZsVmId')

        if zs_group_id is None or zs_vm_id is None:
            raise ValueError("Missing ZsGroupId or ZsVmId")

        zs_group_id = int(zs_group_id)
        zs_vm_id = int(zs_vm_id)

        return zs_group_id, zs_vm_id

    except (ValueError, IndexError) as e:
        logger.warning(f"Invalid Zscaler identifiers from CloudWatch dimensions: {str(e)}")
        return None, None


def get_asg_instance_metadata_and_delete_zscaler_cloud_resource(asg_name, instance_id):
    if asg_name is None or instance_id is None:
        logger.info(f'asg_name: {asg_name} instance_id: {instance_id} one of them is None and hence '
                    f'cannot retreive statistics, cannot handle this event, processing is complete')
        return False
    base_url, dimensions = get_dimensions_for_health_metrics(asg_name, instance_id)
    # TODO check if I broke code by changing this method
    # retrieve zsgroupid and zsvmid
    #  extract_zsgroupid_zsvmid_from_dimensions() expects dimensions in Name,value pair
    # zsgroupid, zsvmid = extract_zsgroupid_zsvmid_from_dimensions(dimensions)

    zsgroupid, zsvmid = extract_zs_group_vm_ids(dimensions)
    if zsgroupid is not None and zsvmid is not None:
        logger.info(f"Zscaler resource deletion planned for zsgroupid: {zsgroupid} zsvmid: {zsvmid}"
                    f"asg_name: {asg_name} instance_id: {instance_id}")

    if zsgroupid and zsvmid:
        # get secret value
        secret_name = os.environ.get('SECRET_NAME', 'dummy_credentials')

        # Call the method to retrieve the secret value
        myapi_key, my_username, my_password = get_secret_value(secret_name)

        # create an authenticated session and delete the zsvmid and logout
        zscaler_api = ZscalerApiClient(myapi_key, my_username, my_password, base_url)
        zscaler_api.process_data(zsgroupid, zsvmid)
        return True


def get_dimensions_for_health_metrics(asg_name, instance_id):
    # Specify the namespace and metric name cloud_connector_aggr_health to get metadata
    namespace = 'Zscaler/CloudConnectors'
    metric_name = 'cloud_connector_aggr_health'
    logger.info(
        f"get_asg_instance_metadata_and_delete_zscaler_cloud_resource: asg_name: {asg_name} instance_id: {instance_id}")
    base_url = extract_base_url()
    dimension_pairs = [('AutoScalingGroupName', asg_name),
                       ('InstanceId', instance_id)]
    dimensions = retrieve_dimensions(namespace, metric_name, dimension_pairs)
    return base_url, dimensions


def extract_base_url():
    cc_url = os.environ.get('CC_URL', 'dummmy_provurl')
    prov_url = "https://" + cc_url
    parsed_url = urlparse(prov_url)
    base_url = "https://" + parsed_url.netloc
    logger.info(f"Zscaler Cloud url: {base_url}")
    return base_url


def is_asg_name_in_list(asg_name):
    # asg_names_list = os.getenv('ASG_NAMES')
    asg_names_list = os.environ.get('ASG_NAMES', '["dummy-asg1"]')
    logger.info(f"managed asg names are: {asg_names_list}")

    if asg_name in asg_names_list:
        return True

    return False


def check_name_in_list(name: str, string_list: List[str]) -> bool:
    return name in string_list


def process_terminated_instance_events(event: object) -> object:
    logger.info(f"process_terminated_instance_events  received: {event}")
    # is the instance static CC VM or ASG
    # if asg need to get validate is this one that is managed by lambda
    # only difference between this and lifecycle termination event is no complete lifecycle action needed.
    # Let's handle only if this instance is part of autoscale group
    response = {
        'statusCode': 200,
        'body': 'Zscaler cloud resources cleaned up successfully'
    }

    # Get the instance ID, asg_name from the event
    instance_id, asg_name = extract_ec2_instance_id_and_asg_name(event)

    if instance_id and asg_name:
        message_body = f"{instance_id} with ASG name {asg_name} is valid. Zscaler cloud resources will be cleaned + " \
                       f"lifecycle action"
        logger.info(message_body)
        is_asg_managed = is_asg_name_in_list(asg_name)
        logger.info(f"is_asg_managed: {is_asg_managed}")
        if not is_asg_managed:
            success_code = 404
            message_body = f"ASG name {asg_name} is valid. Lambda is not managing this asg. no work to be done"
            logger.info(message_body)
            response = {
                'statusCode': success_code,
                'body': message_body
            }
            return response

        get_asg_instance_metadata_and_delete_zscaler_cloud_resource(asg_name, instance_id)
        # can't get hook_name or token from this event
        # let complete_lifecycle_action() handle those case using different API
        if asg_name is not None and instance_id is not None:
            hook_name = None
            token = None
            success = complete_lifecycle_action(hook_name, asg_name, token, instance_id)

            if success:
                # Handle successful completion of the lifecycle action
                logger.info(f"Lifecycle action completed successfully.")
            else:
                # Handle failure in completing the lifecycle action
                logger.error(f"Failed to complete the lifecycle action.")

            success_code = 200
        else:
            success_code = 404
            message_body = f"one of ASG name or instance_id is None. no work to be done"

    elif instance_id:
        message_body = f"{instance_id} is valid, but ASG name is missing. Zscaler cloud resources won't be cleaned"
        logger.info(message_body)
        get_asg_instance_metadata_and_delete_zscaler_cloud_resource(asg_name, instance_id)
        success_code = 200

    elif asg_name:
        success_code = 404
        message_body = f"ASG name {asg_name} is valid, but instance ID is missing. Lambda is not managing this asg"
        logger.info(message_body)
    else:
        message_body = f"Neither instance ID nor ASG name is valid. No need to perform Zscaler cloud resource cleanup."
        logger.info(message_body)
        success_code = 200

    response = {
        'statusCode': success_code,
        'body': message_body
    }
    logger.info(f"Response: {response}")
    return response


def read_sync_environment_variables() -> Dict[str, Any]:
    """
    Read and validate resource-sync environment variables.

    SYNC_DRY_RUN defaults to true: only an explicit 'false' enables real deletions.
    Returns:
        Dict with dry_run, max_deletions, excluded_instances, placeholder_grace_min.
    """
    dry_run = os.environ.get('SYNC_DRY_RUN', 'true').lower() != 'false'

    # SYNC_MAX_DELETIONS_PER_RUN: unset/non-positive = unlimited; a positive
    # integer caps deletions per run across all groups.
    max_deletions = None
    raw_max_deletions = os.environ.get('SYNC_MAX_DELETIONS_PER_RUN', '')
    if raw_max_deletions:
        try:
            parsed = int(raw_max_deletions)
            if parsed <= 0:
                logger.warning(f"SYNC_MAX_DELETIONS_PER_RUN {parsed} is not positive, treating as unlimited")
            else:
                max_deletions = parsed
        except ValueError:
            logger.warning("Invalid SYNC_MAX_DELETIONS_PER_RUN, treating as unlimited")

    try:
        excluded = json.loads(os.environ.get('SYNC_EXCLUDED_INSTANCES', '[]'))
        if not isinstance(excluded, list):
            logger.warning("SYNC_EXCLUDED_INSTANCES is not a JSON array, using empty list")
            excluded = []
    except json.JSONDecodeError:
        logger.warning("Invalid SYNC_EXCLUDED_INSTANCES JSON, using empty list")
        excluded = []

    try:
        grace_min = int(os.environ.get('PLACEHOLDER_UUID_GRACE_PERIOD_MIN',
                                       str(DEFAULT_PLACEHOLDER_UUID_GRACE_PERIOD_MIN)))
        if grace_min < 0:
            logger.warning(f"Negative PLACEHOLDER_UUID_GRACE_PERIOD_MIN {grace_min}, using default")
            grace_min = DEFAULT_PLACEHOLDER_UUID_GRACE_PERIOD_MIN
    except ValueError:
        logger.warning("Invalid PLACEHOLDER_UUID_GRACE_PERIOD_MIN, using default")
        grace_min = DEFAULT_PLACEHOLDER_UUID_GRACE_PERIOD_MIN

    logger.info(f"Resource sync config: dry_run={dry_run}, "
                f"max_deletions={'unlimited' if max_deletions is None else max_deletions}, "
                f"excluded_instances={len(excluded)}, placeholder_grace_min={grace_min}")
    return {
        'dry_run': dry_run,
        'max_deletions': max_deletions,
        'excluded_instances': set(excluded),
        'placeholder_grace_min': grace_min,
    }


def is_resolved_instance_id(uuid) -> bool:
    """True when metaConfig.uuid holds a real EC2 instance id (e.g. i-0abc1234def5678)."""
    return bool(uuid) and RESOLVED_INSTANCE_ID_PATTERN.match(str(uuid)) is not None


def portal_region_to_aws(value) -> str:
    """'US_WEST_2'/'EU_CENTRAL_1A' -> 'us-west-2'/'eu-central-1a'."""
    return value.lower().replace('_', '-') if value else ''


def group_in_region(group: Dict[str, Any], region: str) -> bool:
    """
    True when the group's declared AWS region/AZ matches the Lambda's region.
    Groups without a region field are not excluded; AZ values prefix-match the
    region (eu-central-1a belongs to eu-central-1).
    """
    if not region:
        return True
    for field in ('awsRegion', 'awsAvailabilityZone'):
        raw = group.get(field)
        if raw:
            normalized = portal_region_to_aws(raw)
            return normalized == region or normalized.startswith(region)
    return True


def find_ec_group_for_asg(ec_groups_lite: List[Dict[str, Any]], asg_name: str,
                          region: str = None) -> Union[Dict[str, Any], None]:
    """
    Locate the autoscaling EC group for an ASG.

    Janus creates the group as 'zs-cc-<vpc_id>-<region>-<asg_name>' and stamps
    metaConfig.autoScalingConfig.name = asg_name. Prefer the metaConfig match
    when lite entries carry it; fall back to the group-name suffix match.
    ASG names are unique only within a region, so candidates from other
    regions are excluded when `region` is provided.
    """
    for group in ec_groups_lite or []:
        if not group_in_region(group, region):
            continue
        meta_config = group.get('metaConfig') or group.get('meta_config') or {}
        scaling_config = meta_config.get('autoScalingConfig') or {}
        if scaling_config.get('name') == asg_name:
            return group
    for group in ec_groups_lite or []:
        if not group_in_region(group, region):
            continue
        name = group.get('name', '')
        if name.startswith(f'{EC_GROUP_NAME_PREFIX}-') and name.endswith(f'-{asg_name}'):
            return group
    return None


def get_asg_live_inventory(asg_name: str) -> Tuple[set, bool]:
    """
    All member instance ids of an ASG in ANY lifecycle state, including warm
    pool members. Also reports whether the group has young (still registering)
    instances, which suppresses placeholder-record deletion.

    Returns:
        Tuple[set, bool]: (instance ids, has_young_instances)
    """
    member_ids = set()
    has_young = False

    response = autoscaling_client.describe_auto_scaling_groups(AutoScalingGroupNames=[asg_name])
    asgs = response.get('AutoScalingGroups', [])
    if not asgs:
        logger.warning(f"ASG {asg_name} not found via describe_auto_scaling_groups")
        return member_ids, has_young

    asg = asgs[0]
    for instance in asg.get('Instances', []):
        member_ids.add(instance['InstanceId'])
        if instance.get('LifecycleState', '').startswith(YOUNG_LIFECYCLE_STATE_PREFIXES):
            has_young = True

    if 'WarmPoolConfiguration' in asg:
        next_token = None
        while True:
            kwargs = {'AutoScalingGroupName': asg_name}
            if next_token:
                kwargs['NextToken'] = next_token
            warm_pool_response = autoscaling_client.describe_warm_pool(**kwargs)
            for instance in warm_pool_response.get('Instances', []):
                member_ids.add(instance['InstanceId'])
                if instance.get('LifecycleState', '').startswith(YOUNG_LIFECYCLE_STATE_PREFIXES):
                    has_young = True
            next_token = warm_pool_response.get('NextToken')
            if not next_token:
                break

    return member_ids, has_young


def get_compute_live_inventory(asg_name: str) -> Dict[str, Any]:
    """
    EC2 instances tagged to this ASG that are not terminated. This is the
    second half of the 'absent from group AND compute' staleness check: an
    instance dropped from ASG membership but still present in EC2 is not stale.

    Returns:
        Dict[str, Any]: {instance_id: LaunchTime}
    """
    inventory = {}
    response = ec2_client.describe_instances(
        Filters=[
            {'Name': 'tag:aws:autoscaling:groupName', 'Values': [asg_name]},
            {'Name': 'instance-state-name', 'Values': LIVE_EC2_STATES}
        ]
    )
    for reservation in response.get('Reservations', []):
        for instance in reservation.get('Instances', []):
            inventory[instance['InstanceId']] = instance.get('LaunchTime')
    return inventory


def is_placeholder_stale(ec_vm: Dict[str, Any], grace_period_min: int, now_ts: float) -> bool:
    """
    A placeholder record (unresolved metaConfig.uuid) may only be deleted once
    its first ecInstances registerTime is older than the grace period. Records
    with no registerTime are never aged out this way.
    """
    ec_instances = ec_vm.get('ecInstances') or []
    register_time = ec_instances[0].get('registerTime') if ec_instances else None
    if not register_time:
        return False
    return (now_ts - register_time) > grace_period_min * 60


def process_resource_sync_event(event: Dict[str, Any]) -> Union[Dict[str, Any], None]:
    """
    Reconcile Zscaler EC VM records against live ASG membership.

    Every run: probe the API, build live inventory per ASG (ASG members in any
    lifecycle state, warm pool members, and EC2 instances by autoscaling tag),
    find each ASG's EC group, and delete records whose resolved metaConfig.uuid
    is absent from the live inventory. Placeholder records are only deleted
    after the registerTime grace period and never while the group has young
    instances. Deletions are capped by SYNC_MAX_DELETIONS_PER_RUN (unset =
    unlimited) and followed by a single activation.
    """
    logger.info(f"Processing resource sync event: {event}")
    zscaler_api = None
    total_deleted = 0
    dry_run = True  # safe default: never activate if config was never read
    activation_attempted = False
    try:
        sync_config = read_sync_environment_variables()
        dry_run = sync_config['dry_run']
        max_deletions = sync_config['max_deletions']
        excluded_instances = sync_config['excluded_instances']
        grace_min = sync_config['placeholder_grace_min']

        asg_names = get_asg_names()
        base_url = extract_base_url()
        secret_name = os.environ.get('SECRET_NAME', 'dummy-secret-name')
        api_key, username, password = get_secret_value(secret_name)
        zscaler_api = ZscalerApiClient(api_key, username, password, base_url)

        api_status = zscaler_api.probe_api()
        if api_status == 'maintenance':
            message = 'Zscaler API is in maintenance (HTTP 403); skipping resource sync run'
            logger.warning(message)
            return {'message': message, 'dry_run': dry_run, 'sync_skipped_maintenance': True}
        if api_status != 'up':
            message = 'Zscaler API is unavailable; skipping resource sync run'
            logger.warning(message)
            return {'message': message, 'dry_run': dry_run, 'sync_skipped_unavailable': True}

        zscaler_api.authenticate()
        logger.info("Zscaler API authenticated")
        logger.info("Fetching EC groups lite...")
        ec_groups_lite = zscaler_api.get_ec_groups_lite() or []
        if isinstance(ec_groups_lite, dict):
            ec_groups_lite = [ec_groups_lite]

        # Full ecgroup listing is heavy on large tenants; fetched lazily, only
        # when the lite list yields no match for an ASG.
        ec_groups = None
        region = os.environ.get('AWS_REGION', '') or getattr(autoscaling_client.meta, 'region_name', '')

        sync_results = []

        for asg_name in asg_names:
            if max_deletions is not None and total_deleted >= max_deletions:
                logger.info(f"Reached maximum deletions limit ({max_deletions}), stopping")
                break

            try:
                live_ids, has_young = get_asg_live_inventory(asg_name)
                compute_inventory = get_compute_live_inventory(asg_name)
            except (BotoCoreError, ClientError) as e:
                logger.error(f"Failed to build live inventory for ASG {asg_name}: {e}")
                sync_results.append({'action': 'skipped_inventory_error', 'asg': asg_name, 'error': str(e)})
                continue

            now_ts = time.time()
            for launch_time in compute_inventory.values():
                if launch_time and (now_ts - launch_time.timestamp()) < grace_min * 60:
                    has_young = True
                    break

            live_ids |= set(compute_inventory.keys())
            logger.info(f"ASG {asg_name}: {len(live_ids)} live instances, has_young={has_young}")

            group_ref = find_ec_group_for_asg(ec_groups_lite, asg_name, region)
            if not group_ref:
                if ec_groups is None:
                    try:
                        logger.info(f"No EC group found in lite for ASG {asg_name}, fetching full list...")
                        ec_groups = zscaler_api.get_ec_groups() or []
                        if isinstance(ec_groups, dict):
                            ec_groups = [ec_groups]
                    except Exception as e:
                        logger.error(f"Error fetching EC groups for ASG {asg_name}: {e}")
                        sync_results.append({'action': 'skipped_api_error', 'asg': asg_name, 'error': str(e)})
                        continue
                group_ref = find_ec_group_for_asg(ec_groups, asg_name, region)
            if not group_ref:
                logger.info(f"No EC group found for ASG {asg_name}")
                continue

            try:
                zscaler_group = zscaler_api.get_ec_group_by_name(group_ref.get('name'))
            except Exception as e:
                logger.error(f"Error fetching EC group for ASG {asg_name}: {e}")
                sync_results.append({'action': 'skipped_api_error', 'asg': asg_name, 'error': str(e)})
                continue

            if not zscaler_group:
                logger.warning(f"EC group {group_ref.get('name')} not found by name for ASG {asg_name}")
                continue

            ec_group_id = zscaler_group.get('id')
            ec_vms = zscaler_group.get('ecVMs', [])
            logger.info(f"Found {len(ec_vms)} EC VMs in group {zscaler_group.get('name')} for ASG {asg_name}")

            stale_vms = []
            for ec_vm in ec_vms:
                vm_id = ec_vm.get('id')
                vm_name = ec_vm.get('name', 'Unknown')
                meta_config = ec_vm.get('metaConfig') or {}
                uuid = meta_config.get('uuid', '')

                if uuid in excluded_instances:
                    logger.info(f"Instance {uuid} is excluded from sync, skipping")
                    continue
                if set(ec_vm.get('status') or []) & {'DELETED', 'DELETING', 'DELETING_LAST'}:
                    logger.debug(f"EC VM {vm_id} ({vm_name}) is already DELETING, skipping")
                    continue
                if ec_vm.get('operationalStatus') != 'INACTIVE':
                    logger.debug(f"EC VM {vm_id} ({vm_name}) is not INACTIVE, skipping")
                    continue
                logger.debug(f"EC VM {vm_id} ({vm_name}) is INACTIVE, checking if it's stale")
                if is_resolved_instance_id(uuid):
                    if uuid not in live_ids:
                        logger.info(f"Found stale EC VM: {vm_name} (instance id: {uuid})")
                        stale_vms.append({'ec_vm_id': vm_id, 'ec_vm_name': vm_name, 'uuid': uuid})
                elif not has_young and is_placeholder_stale(ec_vm, grace_min, now_ts):
                    logger.info(f"Found stale placeholder EC VM: {vm_name} (uuid: {uuid!r})")
                    stale_vms.append({'ec_vm_id': vm_id, 'ec_vm_name': vm_name, 'uuid': uuid})

            vms_to_delete = stale_vms if max_deletions is None else stale_vms[:max_deletions - total_deleted]
            for vm_info in vms_to_delete:
                if max_deletions is not None and total_deleted >= max_deletions:
                    break
                try:
                    success = zscaler_api.delete_ec_vm(
                        ec_group_id=ec_group_id,
                        ec_vm_id=vm_info['ec_vm_id'],
                        dry_run=dry_run
                    )
                    if success:
                        total_deleted += 1
                        sync_results.append({
                            'action': 'would_delete' if dry_run else 'deleted',
                            'ec_vm_name': vm_info['ec_vm_name'],
                            'uuid': vm_info['uuid'],
                            'asg': asg_name
                        })
                        # Delete API's are currently rate limited to 1 per second
                        # TODO: remove once rate limit is increased
                        if not dry_run:
                            time.sleep(1)
                    else:
                        sync_results.append({
                            'action': 'failed_to_delete',
                            'ec_vm_name': vm_info['ec_vm_name'],
                            'uuid': vm_info['uuid'],
                            'asg': asg_name
                        })
                except Exception as e:
                    logger.warning(f"Failed to delete EC VM {vm_info['ec_vm_name']}: {e}")
                    sync_results.append({
                        'action': 'failed_to_delete',
                        'ec_vm_name': vm_info['ec_vm_name'],
                        'uuid': vm_info['uuid'],
                        'asg': asg_name,
                        'error': str(e)
                    })

            if len(stale_vms) > len(vms_to_delete):
                remaining = len(stale_vms) - len(vms_to_delete)
                logger.info(f"{remaining} additional stale EC VMs in ASG {asg_name}, will be processed in next run")

        if total_deleted > 0 and not dry_run:
            activation_attempted = True
            logger.info("Activating Zscaler configuration changes")
            if not zscaler_api.activate_changes():
                sync_results.append({
                    'action': 'activation_failed',
                    'note': 'EC VMs were deleted but configuration activation failed'
                })

        action_counts = {}
        for result in sync_results:
            action = result.get('action', 'unknown')
            action_counts[action] = action_counts.get(action, 0) + 1

        action_verb = "Would delete" if dry_run else "Deleted"
        message = f"Resource synchronization completed: {action_verb} {total_deleted} stale EC VM records"
        logger.info(message)
        return {
            'message': message,
            'dry_run': dry_run,
            'total_processed': total_deleted,
            'max_deletions_limit': max_deletions,
            'actions': action_counts,
        }

    except Exception as e:
        logger.error(f"Error processing resource sync event: {e}", exc_info=True)
        return None
    finally:
        # Deletions made before an abnormal exit must still be activated, or
        # they stay pending until some later run happens to delete something.
        if zscaler_api and not activation_attempted and total_deleted > 0 and not dry_run:
            try:
                logger.info("Activating Zscaler configuration changes after incomplete run")
                zscaler_api.activate_changes()
            except Exception as e:
                logger.warning(f"Activation attempt after failure also failed: {e}")
        # Best-effort session cleanup on every exit path; logout() no-ops if
        # authenticate() never ran and swallows its own request errors.
        if zscaler_api:
            zscaler_api.logout()
