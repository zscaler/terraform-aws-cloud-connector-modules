# Zscaler AWS Lambda functionality Release Notes

## Version 1.0.6.2
**Release Date:** [March 24, 2026]

### Security Fixes
- Addressed dependency security hardening for HTTP client libraries used in Lambda packaging.
  - Updated `requests` from version **2.32.2** to **2.32.5**.
  - Explicitly pinned `urllib3` to version **2.6.3**.
  - Packaging now targets CVE remediation for redirect/decompression handling concerns (CVE-2026-21441 / GHSA-38jv-5279-wg99).

### Other Changes
- No functional behavior changes were introduced; this release focuses on dependency security and packaging validation.

## Version 1.0.6.1
**Release Date:** [April 23, 2025]

### Security Fixes
- Addressed a vulnerability found in the `requests` Python library.
  - Updated `requests` from version **2.29.0** to **2.32.2**.
  - This resolves known security concerns related to HTTP request handling.

### Other Changes
- No other functional changes in this release.

---

## Version 1.0.6
**Release Date:** [March 2024]

### Enhancements and Fixes

1. **Enhanced Instance Health Checks**: Lambda now properly respects the Health Check Grace Period configured through IaC. This update prevents premature termination of instances by marking them unhealthy if they breach the health threshold shortly after being moved to InService. This grace period is set to a default duration of 900 seconds, starting immediately after the instance transitions to InService from either the warm pool or a cold EC2 launch.

2. **Secured API Calls to Zscaler Provisioning Server**: Certificate verification is now enabled by default, enhancing the overall security of our integrations.

3. **Reduced CloudWatch Logs Duplication**: A fix has been implemented to address the issue of duplicate log entries being sent to CloudWatch Logs. This change not only simplifies debugging but also reduces associated costs and improves performance.

4. **Optimized Zscaler Cloud Integration**: Added error handling logic to limit unnecessary/excessive API calls made to Zscaler Cloud.

5. **Updated Runtime and Architecture**: The runtime for Python has been upgraded to version 3.12. Furthermore, the default architecture is now set to ARM64 when deployed through Infrastructure as Code (IaC), ensuring improved performance and cost-effectiveness compared to the x86_64 equivalent, along with enhanced compatibility.

6. **Advanced Error Handling and Logging**: Significant improvements have been implemented in error handling and logging mechanisms. This release also introduces support for new environment variables, enhances validation processes, and ensures accurate Lambda metrics reporting.
