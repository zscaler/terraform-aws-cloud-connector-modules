# Zscaler AWS Lambda functionality Release Notes

## Version 1.0.6

### Enhancements and Fixes

1. **Enhanced Instance Health Checks**: Lambda now properly respects the Health Check Grace Period configured through IaC. This update prevents premature termination of instances by marking them unhealthy if they breach the health threshold shortly after being moved to InService. This grace period is set to a default duration of 900 seconds, starting immediately after the instance transitions to InService from either the warm pool or a cold EC2 launch.

2. **Secured API Calls to Zscaler Provisioning Server**: Certificate verification is now enabled by default, enhancing the overall security of our integrations.

3. **Reduced CloudWatch Logs Duplication**: A fix has been implemented to address the issue of duplicate log entries being sent to CloudWatch Logs. This change not only simplifies debugging but also reduces associated costs and improves performance.

4. **Optimized Zscaler Cloud Integration**: Added error handling logic to limit unnecessary/excessive API calls made to Zscaler Cloud.

5. **Updated Runtime and Architecture**: The runtime for Python has been upgraded to version 3.12. Furthermore, the default architecture is now set to ARM64 when deployed through Infrastructure as Code (IaC), ensuring improved performance and cost-effectiveness compared to the x86_64 equivalent, along with enhanced compatibility.

6. **Advanced Error Handling and Logging**: Significant improvements have been implemented in error handling and logging mechanisms. This release also introduces support for new environment variables, enhances validation processes, and ensures accurate Lambda metrics reporting.
