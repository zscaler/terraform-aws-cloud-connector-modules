"""
Copyright (C) 2007-2024 Zscaler, Inc. All rights reserved.
Unauthorized copying of this file, via any medium is strictly prohibited
Proprietary and confidential
"""
import os
import time
from typing import Tuple, Optional
from urllib.parse import urlparse

import requests
from requests.models import Response

from utils.log_config import setup_logger
from utils.secret_manager import get_secret_value

logger = setup_logger(__name__)


# Create custom Exceptions rather than using generic Exceptions
class AuthenticationError(Exception):
    """Custom exception for authentication errors."""
    pass


class ApiRequestError(Exception):
    """Custom exception for API request errors."""
    def __init__(self, message: str, status_code: int = None):
        super().__init__(message)
        self.status_code = status_code


class ZscalerApiClient:
    def __init__(self, api_key: str, username: str, password: str, base_url: str) -> None:
        self.api_key = api_key
        self.username = username
        self.password = password
        self.base_url = base_url
        self.jsessionid = None

        # Fetch and convert CERTIFICATE_VERIFY from the environment variable
        certificate_verify_str = os.environ.get('CERTIFICATE_VERIFY', 'true').lower()
        self.certificate_verify = certificate_verify_str == 'true'

    @staticmethod
    def obfuscate_api_key(seed: str) -> Tuple[int, str]:
        now = int(time.time() * 1000)
        n = str(now)[-6:]
        r = str(int(n) >> 1).zfill(6)
        key = ""
        for i in range(0, len(str(n)), 1):
            key += seed[int(str(n)[i])]
        for j in range(0, len(str(r)), 1):
            key += seed[int(str(r)[j]) + 2]

        return now, key

    def authenticate(self) -> None:
        auth_url = f"{self.base_url}/api/v1/auth"
        timestamp, new_api_key = self.obfuscate_api_key(self.api_key)
        auth_payload = {
            "apiKey": new_api_key,
            "username": self.username,
            "password": self.password,
            "timestamp": timestamp
        }
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json"
        }

        response = requests.post(auth_url, json=auth_payload, headers=headers, verify=self.certificate_verify)

        if response.status_code == 200:
            self.jsessionid = response.cookies.get('JSESSIONID')
            logger.info("Authentication successful.")
        else:
            logger.error(f"Authentication failed. HTTP status code: {response.status_code}")
            raise AuthenticationError("Failed to authenticate with Zscaler API")

    @staticmethod
    def is_retryable_error(status_code: int) -> bool:
        """Check if the error is retryable based on the status code."""
        retryable_errors = [500, 502, 503, 504, 408, 429]
        return status_code in retryable_errors

    def make_api_request(self, url: str, method: str = 'get', payload: dict = None) -> Optional[Response]:
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Cookie": f"JSESSIONID={self.jsessionid}"
        }
        logger.info(f"Making {method} request to URL: {url}")

        max_retries = 3
        retries = 0
        delay = 1  # initial delay in seconds

        while retries < max_retries:
            try:
                if method == 'get':
                    response = requests.get(url, headers=headers, verify=self.certificate_verify)
                elif method == 'post':
                    response = requests.post(url, json=payload, headers=headers, verify=self.certificate_verify)
                elif method == 'put':
                    response = requests.put(url, json=payload, headers=headers, verify=self.certificate_verify)
                elif method == 'delete':
                    response = requests.delete(url, headers=headers, verify=self.certificate_verify)
                else:
                    raise ValueError("Invalid HTTP method")

                logger.info(f"{method.upper()} request to {url} completed with status code: {response.status_code}")

                if 200 <= response.status_code < 300:
                    return response  # Return the response object
                elif ZscalerApiClient.is_retryable_error(response.status_code):
                    retries += 1
                    # Honor Retry-After when the API asks for a pause (e.g. 429),
                    # capped so a single request can't stall the whole invocation.
                    retry_after = response.headers.get('Retry-After')
                    if retry_after:
                        try:
                            delay = min(max(int(retry_after), delay), 60)
                        except ValueError:
                            pass
                    logger.warning(f"Retryable error encountered. "
                                   f"Retrying in {delay} seconds... (Attempt {retries}/{max_retries})")
                    time.sleep(delay)
                    delay *= 2  # Exponential backoff
                else:
                    raise ApiRequestError(
                        f"Non-retryable API request error with status code {response.status_code}",
                        status_code=response.status_code)

            except (requests.exceptions.RequestException, ValueError) as e:
                logger.error(f"Error occurred during API request: {str(e)}")
                if retries >= max_retries - 1:
                    raise ApiRequestError("Error occurred during API request") from e
                else:
                    retries += 1
                    logger.warning(f"Encountered a request exception. "
                                   f"Retrying in {delay} seconds... (Attempt {retries}/{max_retries})")
                    time.sleep(delay)
                    delay *= 2  # Exponential backoff

        raise ApiRequestError("Maximum retry attempts reached")

    def process_data(self, zs_group_id: int, zs_vm_id: int) -> None:
        # Step 1: Authenticate and obtain JSESSIONID
        self.authenticate()

        try:
            zs_group_id = int(zs_group_id)
            zs_vm_id = int(zs_vm_id)
        except (TypeError, ValueError):
            logger.error("Invalid Zscaler identifiers provided for API path construction.")
            return

        # Function to check if the status code indicates success
        def is_successful_status(response: Response) -> bool:
            """Check if the HTTP response has a successful status code."""
            return response is not None and 200 <= response.status_code < 300

        # # Step 2: Use JSESSIONID for further API calls
        # ecgrouplite_url = f"{self.base_url}/api/v1/ecgroup/lite"
        # self.make_api_request(ecgrouplite_url)
        #
        # # Step 3: Read ecvmid
        ecvm_url: str = f"{self.base_url}/api/v1/ecgroup/{zs_group_id}/vm/{zs_vm_id}"
        response = self.make_api_request(ecvm_url)
        if not is_successful_status(response):
            logger.error(f"Failed to read ecvmid. Status code: {response.status_code if response else 'No response'}")
            return

        # Step 4: Delete the ecvmid
        delete_response = self.make_api_request(ecvm_url, method='delete')
        if not is_successful_status(delete_response):
            logger.error(
                f"Failed to delete ecvmid. Status code: {delete_response.status_code if delete_response else 'No response'}")
            return

        # Step 5: Get ecAdminActivateStatus
        ec_admin_activate_status_url = f"{self.base_url}/api/v1/ecAdminActivateStatus"
        activate_status_response = self.make_api_request(ec_admin_activate_status_url)
        if not is_successful_status(activate_status_response):
            logger.error(
                f"Failed to get ecAdminActivateStatus. Status code: {activate_status_response.status_code if activate_status_response else 'No response'}")
            return

        # Step 6: Activate using Put
        ec_admin_activate_url: str = f"{self.base_url}/api/v1/ecAdminActivateStatus/activate"
        activate_response = self.make_api_request(ec_admin_activate_url, method='put')
        if not is_successful_status(activate_response):
            logger.error(
                f"Activation failed. Status code: {activate_response.status_code if activate_response else 'No response'}")
            return

        # Step 7: Logout using delete
        logout_url = f"{self.base_url}/api/v1/auth"
        logout_response = self.make_api_request(logout_url, method='delete')
        if not is_successful_status(logout_response):
            logger.error(
                f"Failed to logout. Status code: {logout_response.status_code if logout_response else 'No response'}")

    def probe_api(self) -> str:
        """
        Unauthenticated liveness probe on GET /api/v1/ecgroup/lite.

        Returns:
            str: 'up' when the API responds normally (401/2xx/other 4xx),
                 'maintenance' when the portal is in maintenance (HTTP 403),
                 'unavailable' on 5xx or network errors.
        """
        url = f"{self.base_url}/api/v1/ecgroup/lite"
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json"
        }
        try:
            response = requests.get(url, headers=headers, verify=self.certificate_verify, timeout=30)
        except requests.exceptions.RequestException as e:
            logger.warning(f"API probe failed with request exception: {e}")
            return "unavailable"

        if response.status_code == 403:
            logger.warning("API probe returned 403: portal is in maintenance")
            return "maintenance"
        if response.status_code == 401 or 200 <= response.status_code < 300 or 400 <= response.status_code < 500:
            return "up"
        logger.warning(f"API probe returned unexpected status code: {response.status_code}")
        return "unavailable"

    def get_ec_groups_lite(self) -> Optional[list]:
        """
        Retrieves all EC groups in lite form.
        Returns:
            list: List of EC group dicts, or None on failure.
        """
        url = f"{self.base_url}/api/v1/ecgroup/lite"
        response = self.make_api_request(url)
        if response is None:
            return None
        return response.json()
    
    def get_ec_groups(self) -> Optional[list]:
        """
        Retrieves all EC groups.
        Returns:
            list: List of EC group dicts, or None on failure.
        """
        url = f"{self.base_url}/api/v1/ecgroup"
        response = self.make_api_request(url)
        if response is None:
            return None
        return response.json()

    def get_ec_group_by_name(self, ec_group_name: str) -> Optional[dict]:
        """
        Retrieves a full EC group (including ecVMs) by name.
        Returns:
            dict: The EC group dict, or None when not found.
        """
        url = f"{self.base_url}/api/v1/ecgroup?name={ec_group_name}"
        response = self.make_api_request(url)
        if response is None:
            return None
        body = response.json()
        if isinstance(body, list):
            return body[0] if body else None
        return body

    def delete_ec_vm(self, ec_group_id: int, ec_vm_id: int, dry_run: bool = False) -> bool:
        """
        Deletes a specific EC VM from an EC group. 404/409 on DELETE means the
        record is already gone and is treated as success.
        Returns:
            bool: True when the record is gone (or would be in dry run), False otherwise.
        """
        if dry_run:
            logger.info(f"DRY RUN: Would delete EC VM {ec_vm_id} from group {ec_group_id}")
            return True

        ecvm_url = f"{self.base_url}/api/v1/ecgroup/{ec_group_id}/vm/{ec_vm_id}"
        try:
            response = self.make_api_request(ecvm_url, method='delete')
            if response is not None and 200 <= response.status_code < 300:
                logger.info(f"Successfully deleted EC VM {ec_vm_id} from group {ec_group_id}")
                return True
            logger.error(f"Failed to delete EC VM {ec_vm_id} from group {ec_group_id}")
            return False
        except ApiRequestError as e:
            if e.status_code in (404, 409):
                logger.info(f"EC VM {ec_vm_id} in group {ec_group_id} is already gone, treating as deleted")
                return True
            logger.error(f"Failed to delete EC VM {ec_vm_id} from group {ec_group_id}: {e}")
            return False

    def activate_changes(self, dry_run: bool = False) -> bool:
        """
        Activates pending Zscaler admin changes.
        Returns:
            bool: True on success (or in dry run), False otherwise.
        """
        if dry_run:
            logger.info("DRY RUN: Would activate Zscaler admin changes")
            return True

        try:
            ec_admin_activate_status_url = f"{self.base_url}/api/v1/ecAdminActivateStatus"
            self.make_api_request(ec_admin_activate_status_url)

            ec_admin_activate_url = f"{self.base_url}/api/v1/ecAdminActivateStatus/activate"
            self.make_api_request(ec_admin_activate_url, method='put')
            logger.info("Successfully activated Zscaler admin changes")
            return True
        except ApiRequestError as e:
            logger.error(f"Failed to activate Zscaler admin changes: {e}")
            return False

    def logout(self) -> None:
        """Best-effort session logout; clears the local JSESSIONID either way."""
        if not self.jsessionid:
            return
        try:
            logout_url = f"{self.base_url}/api/v1/auth"
            self.make_api_request(logout_url, method='delete')
        except Exception as e:
            logger.warning(f"Logout request failed: {e}")
        finally:
            self.jsessionid = None


def main():
    try:
        test_zscaler_resource_deletion()
    except AuthenticationError as e:
        logger.error(f"An error occurred during authentication: {e}")
    except Exception as e:
        logger.error(f"An unexpected error occurred: {e}")


def test_zscaler_resource_deletion():
    cc_url = os.environ['CC_URL']

    secret_name = os.environ['SECRET_NAME']

    # Call the method to retrieve the secret value
    api_key, username, password = get_secret_value(secret_name)

    prov_url = "https://" + cc_url
    parsed_url = urlparse(prov_url)
    base_url = "https://" + parsed_url.netloc
    logger.info(f"Zscaler Cloud url: {base_url}")
    start_time = time.time()
    zscaler_api = ZscalerApiClient(api_key, username, password, base_url)
    # Test data
    zs_group_id: int = 1234
    zs_vm_id = 4567
    zscaler_api.process_data(zs_group_id, zs_vm_id)
    end_time = time.time()
    execution_time = end_time - start_time
    logger.info(f"Time taken: {execution_time} seconds")


if __name__ == "__main__":
    main()
