import json
import boto3
import logging
import datetime
import os

# Set up logging
logger = logging.getLogger()
logger.setLevel(logging.DEBUG)

# Define variables
custom_namespace = 'Zscaler/CloudConnectors'
dimension_name = 'AutoScalingGroupName'
dimension_value = 'vkmay20-cc-asg-xhlsy0ko'
instance_name = 'InstanceId'
instance_value = 'i-093fdbd1e654be354'
custom_metric = 'smedge_cpu_utilization'
# custom_metric = 'cloud_connector_gw_health'
smedge_cpu_utilization_unit = 'Percent'
smedge_cpu_utilization_stat = 'Average'
health_unit = 'Percent'
health_stat = 'Maximum'

# Set up the boto3 client for Auto Scaling and EC2
autoscaling = boto3.client('autoscaling')
ec2 = boto3.client('ec2')


def lambda_handler(event, context):
    # dump the event and context
    logger.info(f'Zscaler lambda_handler: event={event} and context={context}')

    # read Environment Variables
    asg_list = os.environ['ASG_NAMES']
    cc_url = os.environ['CC_URL']
    secret_name: str = os.environ['SECRET_NAME']
    hc_data_points = os.environ['HC_DATA_POINTS']
    hc_unhealthy_threshold = os.environ['HC_UNHEALTHY_THRESHOLD']
    logger.info(
        f'#asg_list# {asg_list} #c_url# {cc_url} #secret_name# {secret_name} #hc_data_points# {hc_data_points} #hc_unhealthy_threshold# {hc_unhealthy_threshold}')

    detail_type = event.get('detail-type')
    if detail_type == 'Scheduled Event':
        process_scheduled_event(event)
    elif detail_type == 'EC2 Instance-terminate Lifecycle Action':
        process_terminate_lifecycle_action(event)
    elif detail_type == 'EC2 Instance State-change Notification':
        process_terminated_instance_action(event)
    else:
        logger.warning("Unknown event detail-type: %s", detail_type)

    return {
        'statusCode': 200,
        'body': json.dumps('Zscaler lambda_handler Completed')
    }


def process_scheduled_event(event):
    logger.info("Processing Scheduled Event: %s", event)
    # Check health of the instance and set custom autoscale health if unhealthy
    process_fault_management_event(event)


def process_terminate_lifecycle_action(event):
    logger.info("Processing Autoscale Instance-terminate Lifecycle Action: %s", event)
    # processing the EC2 Instance-terminate Lifecycle Action
    process_lifecycle_termination_events(event)


def process_terminated_instance_action(event):
    logger.info("Processing EC2 Instance-terminate Lifecycle Action: %s", event)
    # processing the EC2 Instance-terminate Lifecycle Action
    process_terminated_instance_events(event)


def process_fault_management_event(event):
    logger.info(f"process_fault_management_event received: {event}")
    # Get the Auto Scaling group name
    auto_scaling_group_name = dimension_value

    # Get the in-service instances from the Auto Scaling group
    in_service_instances = get_in_service_instances(auto_scaling_group_name)
    logger.info(
        f"Zscaler ASG: Inservice Instances list is {in_service_instances} for asg name {auto_scaling_group_name}")

    # Retrieve all dimensions associated with the metric
    retrieve_all_dimensions()

    # Retrieve last 5 entries of the metric for the instanceID
    retrieve_last_5_entries()


def retrieve_last_5_entries():
    logger.info("Entering retrieve_last_5_entries")
    client = boto3.client('cloudwatch')
    start_time = datetime.datetime.now() - datetime.timedelta(minutes=30)
    end_time = datetime.datetime.now() - datetime.timedelta(minutes=10)
    logger.info('zscaler: Retrieving metric data from {} to {}'.format(start_time, end_time))

    response = client.get_metric_data(
        MetricDataQueries=[
            {
                'Id': 'm1',
                'MetricStat': {
                    'Metric': {
                        'Namespace': custom_namespace,
                        'MetricName': custom_metric,
                        'Dimensions': [
                            {
                                'Name': dimension_name,
                                'Value': dimension_value
                            }
                        ]
                    },
                    'Period': 60,
                    'Stat': smedge_cpu_utilization_stat,
                    'Unit': smedge_cpu_utilization_unit
                }
            }
        ],
        StartTime=start_time,
        EndTime=end_time,
        ScanBy='TimestampDescending',
        MaxDatapoints=3
    )
    logger.info(f"retrieved get_metric_data(): {response}")
    logger.info(f'response["MetricDataResults"][0]["Values"]')
    if response['ResponseMetadata']['HTTPStatusCode'] == 200:
        if response['Messages']:
            logger.warning('Partial data received. Some metric data points may be missing.')

        logger.info('Last 3 entries retrieved successfully!')

        # Process the metric data points
        if 'MetricDataResults' in response:
            for result in response['MetricDataResults']:
                if 'Timestamps' in result and 'Values' in result:
                    timestamps = result['Timestamps']
                    values = result['Values']

                    for timestamp, value in zip(timestamps, values):
                        logger.info('Timestamp: {}, Value: {}'.format(timestamp, value))
                else:
                    logger.warning('Missing Timestamps or Values in MetricDataResults.')
    else:
        logger.error(
            'Failed to retrieve metric data. Status code: {}'.format(response['ResponseMetadata']['HTTPStatusCode']))


def retrieve_all_dimensions():
    logger.info("Entering retrieve_all_dimensions")
    client = boto3.client('cloudwatch')
    response = client.list_metrics(
        Namespace=custom_namespace,
        MetricName=custom_metric
    )
    logger.info(response)
    dimensions = [metric['Dimensions'] for metric in response['Metrics']]
    logger.info('Dimensions associated with the metric:')
    logger.info(dimensions)


def process_results(instance_id, health_probe_results):
    # Check if 3 out of 5 health probe results are false
    if health_probe_results.count(0) >= 3:
        logger.info(f"zscaler: process_results found unhealthy datapoint count of {health_probe_results.count(0)}")
        # Set the custom Auto Scaling group health check for the instance as unhealthy
        autoscaling.set_instance_health(
            InstanceId=instance_id,
            HealthStatus='Unhealthy',
            ShouldRespectGracePeriod=False
        )


def get_in_service_instances(auto_scaling_group_name):
    # Retrieve in-service instances from the Auto Scaling group
    response = ec2.describe_instances(
        Filters=[
            {'Name': 'tag:aws:autoscaling:groupName', 'Values': [auto_scaling_group_name]},
            {'Name': 'instance-state-name', 'Values': ['running']}
        ]
    )

    in_service_instances = []
    for reservation in response['Reservations']:
        for instance in reservation['Instances']:
            instance_id = instance['InstanceId']
            in_service_instances.append(instance_id)
            logger.info(f"In-Service Instance ID: {instance_id}")

    return in_service_instances


def process_lifecycle_termination_events(event):
    logger.info(f"process_lifecycle_termination_events  received: {event}")

    # Get the instance ID and lifecycle action token from the event
    instance_id = event['detail']['EC2InstanceId']
    token = event['detail']['LifecycleActionToken']

    # Get the Auto Scaling group name from the environment variables
    asg_names = os.environ['ASG_NAMES']
    asg_name = asg_names[0]

    # read the lifecycle name from asg
    hook_name = "vkmay20-cc-asg-lifecyclehook-terminate-xhlsy0ko"
    logger.info(f"hook_name: {hook_name} asgName: {asg_name}")
    logger.info(f"instance_id: {instance_id}")

    # Determine if the instance is part of a warmed pool and is being terminated
    if event['detail']['LifecycleTransition'] == 'autoscaling:EC2_INSTANCE_TERMINATING' and event['detail'][
        'LifecycleHookName'] == hook_name:
        response = autoscaling.describe_auto_scaling_instances(InstanceIds=[instance_id])
        logger.info(f"describe_auto_scaling_instances: {response}")
        instances = response['AutoScalingInstances']
        if instances and instances[0]['LifecycleState'] == 'Warmed:Terminating:Wait':

            # If this is a warmed pool instance that is being terminated, complete the lifecycle action to allow the
            # instance to be terminated TODO readFromSecretManager() readZscalerEcId() createSessionToZsApiServer()
            #  sendDeleteEcVm(): add retry logic

            response = autoscaling.complete_lifecycle_action(
                LifecycleHookName=hook_name,
                AutoScalingGroupName=asg_name,
                LifecycleActionToken=token,
                LifecycleActionResult='CONTINUE',
                InstanceId=instance_id
            )
            logger.info(f"lifecycycleaction response {response}"")")

        else:
            logger.info(f"lifecycycleaction NOT  Warmed:Terminating:Wait")

    response = {
        'statusCode': 200,
        'body': 'Autoscale Lifecycle action completed and Zscaler cloud resources cleaned up successfully'
    }
    return response


def process_terminated_instance_events(event: object) -> object:
    logger.info(f"process_terminated_instance_events  received: {event}")

    response = {
        'statusCode': 200,
        'body': 'Zscaler cloud resources cleaned up successfully'
    }
    return response
