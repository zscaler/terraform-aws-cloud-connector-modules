import boto3
import json
import os
import random
import urllib3
import time
from botocore.exceptions import ClientError
from itertools import cycle
from multiprocessing import Process, Pipe

# Constants
HTTP_PROBE_PORT_DEFAULT = 80
PROBE_COUNT_DEFAULT = 3
MIN_PROBE_COUNT = 1
MAX_PROBE_COUNT = 4
PROBE_INTERVAL_SECS_DEFAULT = 7
MIN_PROBE_INTERVAL_SECS = 5
MAX_PROBE_INTERVAL_SECS = 14

# ONE TIME INITS
EC2_RESOURCE = boto3.resource('ec2')
print(f"Connected to ec2")
HTTP = urllib3.PoolManager()


def get_instance_data(instance_dict, child_conn):
    instance_id = instance_dict.get('instance-id')
    http_probe_port = instance_dict.get('http-probe-port')
    instance = EC2_RESOURCE.Instance(instance_id)
    try:
        instance.load()
    except ClientError as e:
        raise Exception(f"Unable to retrieve instance information for {instance_id}: {e}")
    instance_state = instance.state['Name']
    service_eni, service_ip = [(nia["NetworkInterfaceId"], nia["PrivateIpAddress"]) for nia in
                  instance.network_interfaces_attribute if nia.get(
            "Attachment").get("DeviceIndex") == 1][0]

    instance_dict.update({
        'state': instance_state,
        'service_eni': service_eni,
        'service_ip': service_ip,
        'http_probe_port': http_probe_port
    })
    cc_alive = check_cc_health(instance_dict)
    instance_dict['health'] = instance_state.lower() == 'running' and cc_alive
    child_conn.send(instance_dict)
    child_conn.close()


def check_cc_health(instance_dict):
    # 1. find the service_ip, health_probe_port, max_probe, max_probe_interval_secs
    service_ip = instance_dict['service_ip']
    http_probe_port = instance_dict['http_probe_port']
    probe_count = os.environ.get('PROBE_COUNT', PROBE_COUNT_DEFAULT)
    if probe_count < MIN_PROBE_COUNT or probe_count > MAX_PROBE_COUNT:
        probe_count = MIN_PROBE_COUNT
    probe_interval_secs = os.environ.get('PROBE_INTERVAL_SECS', PROBE_INTERVAL_SECS_DEFAULT)
    if probe_interval_secs < MIN_PROBE_INTERVAL_SECS or probe_interval_secs > MAX_PROBE_INTERVAL_SECS:
        probe_interval_secs = PROBE_INTERVAL_SECS_DEFAULT

    # set the probe endpoint
    url = f'http://{service_ip}:{http_probe_port}/?cchealth'
    print(url)
    # 2. send an http probe to the endpoint
    for count in list(reversed(range(probe_count))):
        try:
            resp = HTTP.request("GET", url, timeout=urllib3.Timeout(connect=1.0), retries=False)
            # 3. if port is alive, return True
            print(f'HTTP Response Status: {resp.status}')
            if resp.status == 200:
                return True
            if count:
                time.sleep(probe_interval_secs)
        except urllib3.exceptions.ConnectTimeoutError as e:
            # else wait for probe_interval_secs if count is still positive
            if count:
                time.sleep(probe_interval_secs)
    return False


def lambda_handler(event, context):
    """
    On Instance State Change Event (monitoring for stopping, stopped, terminated,
    shutting-down: Maybe we should do only stopping/shutting-down),

    1. Load env var, connect to SSM and retrieve parameters_by_path hierarchy
        /<deployment ID or Cloudformation Stack Name>/
              /<instance-ID>/route-tables
              /<instance-ID>/route-tables
              /<instance-ID>/route-tables
              <...>

    2. Connect to EC2 resource and retrieve the instance states, classifying
    running/non-running instances
    3. Iterate through each instance's route tables list.
        If instance is running and a route is not pointing to instance's eni,
        change it to instance's eni.
        If instance is not running then select an eni based on
        route_change_strategy from the set of
        running enis and point the route table route to it for each of the instance
        route table
    """
    print(f"Event:{event}")

    # parameter_store_path = os.environ.get("parameter_store_path")
    # Possible route change strategies are,
    # failover_routes_to_remaining_actives (default)
    # failover_routes_to_any_one_active_node
    route_change_strategy = os.environ.get(
        'ROUTE_CHANGE_STRATEGY', "distribute_routes_equally")
    environs = json.loads(os.environ.get('ENVIRONS'))
    instances = environs.get('INSTANCES').split(',')

    non_running_instances = list()
    running_instances = list()
    all_service_enis = list()
    running_service_enis = list()
    non_running_service_enis = list()
    processes = []
    # create a list to keep connections
    parent_connections = []

    for index, instance in enumerate(instances):
        instance_dict = dict()
        instance_dict['instance-id'] = instance
        instance_dict['http-probe-port'] = environs.get(instance).get("HttpProbePort")
        instances[index] = instance_dict
        parent_conn, child_conn = Pipe()
        parent_connections.append(parent_conn)
        process = Process(target=get_instance_data, args=(instance_dict, child_conn,))
        processes.append(process)
        process.start()

    print(f'Waiting for instance data retrieval to complete...')
    while True in [p.is_alive() for p in processes]:
        time.sleep(0.1)
    print(f'Done retrieving instance data.')
    for index, parent_connection in enumerate(parent_connections):
        instances[index] = parent_connection.recv()

    for instance_dict in instances:
        try:
            instance_health = instance_dict.get('health')
            instance = instance_dict.get("instance-id")
            instance_service_eni = instance_dict.get("service_eni")
            print(f"Cloud Connector Instance {instance} is" +
                  [" not ", " "][instance_health] + "active")
            [non_running_instances, running_instances][instance_health].append(instance_dict)
            [non_running_service_enis, running_service_enis][instance_health].append(
                instance_service_eni)
            all_service_enis.append(instance_service_eni)
        except Exception as e:
            raise e

    if len(non_running_instances) == len(instances):
        print("Route Change is not possible as there are no active instances!")
        return None
    # Route Change Code
    # Iterate instances' route-tables list from parameter store
    for instance_dict in instances:
        instance_id = instance_dict.get('instance-id')
        instance_health = instance_dict.get("health")
        instance_service_eni = instance_dict.get("service_eni")
        # Route table IDs are stored as a string list in the env var keyed by
        # instance id
        value = environs.get(instance_id).get("RouteTables")
        route_table_ids = list()
        if value != "None":
            route_table_ids = value.split(',')
        if not len(route_table_ids):
            continue
        route_table_filters = [{"Name": "route-table-id", "Values": route_table_ids}]
        # Get the route tables to operate on
        route_tables_generator = EC2_RESOURCE.route_tables.filter(
            Filters=route_table_filters)
        # Route change strategy
        if instance_health:
            candidate_enis = [instance_service_eni]
        else:
            # Use the default route change strategy first
            candidate_enis = running_service_enis
            if route_change_strategy == "failover_routes_to_any_one_active_node":
                candidate_enis = [random.choice(running_service_enis)]
        candidate_eni_pool = cycle(candidate_enis)
        for route_table in route_tables_generator:
            for route in route_table.routes:
                # First the case where we have to change a down node's routes
                needs_route_change = False
                if route.network_interface_id == instance_service_eni and not \
                        instance_health:
                    print("Route {0} in table {1} has the cc eni {2} as "
                          "nexthop, need to modify!".format(route, route_table,
                                                            instance_service_eni))
                    needs_route_change = True
                elif instance_health and route.network_interface_id != \
                        instance_service_eni \
                        and \
                        route.network_interface_id in all_service_enis:
                    print("Route {0} in table {1} has the cc eni {2} as "
                          "nexthop, where it should be {3} need to "
                          "modify!".format(route, route_table,
                                           route.network_interface_id,
                                           instance_service_eni))
                    needs_route_change = True

                if needs_route_change:
                    replacement_service_eni = next(candidate_eni_pool)
                    try:
                        route.replace(NetworkInterfaceId=replacement_service_eni)
                        print("Done replacing route nexthop!")
                    except ClientError as e:
                        print("Unable to modify Route {0} in table {1} to the "
                              "cc eni {2} as "
                              "nexthop: {3}".format(route, route_table,
                                                    replacement_service_eni, e))
